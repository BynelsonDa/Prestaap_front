package com.fastcredit.app

import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.fastcredit.app.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private var isPasswordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // ── Password toggle ────────────────────────────────────────────
        binding.ivPasswordToggle.setOnClickListener {
            isPasswordVisible = !isPasswordVisible
            binding.etPassword.transformationMethod = if (isPasswordVisible)
                HideReturnsTransformationMethod.getInstance()
            else
                PasswordTransformationMethod.getInstance()
            // Move cursor to end after toggling
            binding.etPassword.setSelection(binding.etPassword.text?.length ?: 0)
        }

        // ── Login button ───────────────────────────────────────────────
        binding.btnLogin.setOnClickListener {
            val username = binding.etUsername.text?.toString()?.trim() ?: ""
            val password = binding.etPassword.text?.toString() ?: ""

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Por favor ingresa usuario y contraseña", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // TODO: Replace with real authentication logic
            Toast.makeText(this, "Iniciando sesión…", Toast.LENGTH_SHORT).show()
            // startActivity(Intent(this, MainActivity::class.java))
        }

        // ── Forgot password ────────────────────────────────────────────
        binding.tvForgotPassword.setOnClickListener {
            // TODO: Navigate to password recovery screen
            Toast.makeText(this, "Recuperación de contraseña próximamente", Toast.LENGTH_SHORT).show()
        }

        // ── Back / Next nav ────────────────────────────────────────────
        binding.btnLoginNext.setOnClickListener {
            binding.btnLogin.performClick()
        }
    }
}
