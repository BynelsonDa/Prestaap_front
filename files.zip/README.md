# FastCredit — Android Studio Frontend

Implementación de los mockups de Figma para **FastCredit**, app de gestión de créditos.

## Archivos incluidos

```
app/
├── src/main/
│   ├── AndroidManifest.xml
│   ├── java/com/fastcredit/app/
│   │   ├── StartupActivity.kt       ← Pantalla de bienvenida / onboarding
│   │   └── LoginActivity.kt         ← Pantalla de login
│   └── res/
│       ├── layout/
│       │   ├── activity_startup.xml ← Layout startup screen
│       │   └── activity_login.xml   ← Layout login screen
│       ├── drawable/
│       │   ├── bg_panel_rounded.xml ← Panel azul con bordes redondeados
│       │   ├── bg_feature_card.xml  ← Tarjeta de feature
│       │   ├── bg_input_field.xml   ← Campo de texto
│       │   ├── bg_btn_white.xml     ← Botón blanco
│       │   ├── bg_btn_circle_blue.xml ← FAB circular
│       │   ├── bg_icon_circle.xml   ← Contenedor de icono
│       │   ├── dot_active.xml       ← Indicador dot activo (pill)
│       │   └── dot_inactive.xml     ← Indicador dot inactivo
│       └── values/
│           ├── colors.xml
│           ├── strings.xml
│           └── themes.xml
└── build.gradle
```

## Cómo usar en Android Studio

1. Abre Android Studio → **File > New > New Project** con plantilla Empty Activity
2. Reemplaza los archivos generados con los de esta carpeta
3. Asegúrate de que el `namespace` en `build.gradle` coincida con tu paquete
4. Agrega tu propio logo en `res/drawable/ic_logo.xml` (vector) y reemplaza las referencias `@drawable/ic_launcher_foreground`
5. Sincroniza Gradle → **Sync Project with Gradle Files**
6. Ejecuta en emulador o dispositivo

## Dependencias requeridas (ya en build.gradle)

```gradle
implementation 'com.google.android.material:material:1.11.0'
implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
implementation 'androidx.coordinatorlayout:coordinatorlayout:1.2.0'
```

## Paleta de colores

| Token          | Hex       | Uso                        |
|----------------|-----------|----------------------------|
| bg_dark        | #1A1A2E   | Fondo oscuro general       |
| bg_panel       | #2563EB   | Panel inferior azul        |
| brand_green    | #22C55E   | Logo / acentos             |
| card_bg        | #1E3A8A   | Fondo tarjetas             |
| card_border    | #3B82F6   | Borde tarjetas             |
| text_white     | #FFFFFF   | Texto principal            |
| text_light     | #CBD5E1   | Texto secundario           |

## Pendiente para completar

- [ ] Reemplazar `@drawable/ic_launcher_foreground` con logo SVG real de FastCredit
- [ ] Implementar lógica de autenticación en `LoginActivity.kt`
- [ ] Crear `MainActivity` para el dashboard principal
- [ ] Agregar animaciones de transición entre pantallas
